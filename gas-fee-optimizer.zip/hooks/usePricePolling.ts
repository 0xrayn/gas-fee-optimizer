"use client";

import { useState, useEffect, useRef } from "react";
import type { Chain } from "@/types";

export const PRICE_DISPLAY_LABEL: Record<Chain, string> = {
  ETH:   "ETH",
  MATIC: "MATIC",
  ARB:   "ARB",
};

interface PriceData {
  price: number;
  priceChange: number;
  isLoading: boolean;
  ethPrice: number; // harga ETH — untuk TxEstimator ARB (gas dibayar ETH)
}

const priceCache: Partial<Record<Chain, { price: number; priceChange: number; ethPrice: number; ts: number }>> = {};
const CACHE_TTL_MS = 55_000;

export function usePricePolling(chain: Chain): PriceData {
  const initCache = priceCache[chain];
  const [price, setPrice]             = useState(initCache?.price ?? 0);
  const [priceChange, setPriceChange] = useState(initCache?.priceChange ?? 0);
  const [ethPrice, setEthPrice]       = useState(initCache?.ethPrice ?? 0);
  const [isLoading, setIsLoading]     = useState(!initCache);

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const chainRef = useRef(chain);

  const fetchPrice = async (c: Chain) => {
    try {
      const res = await fetch(`/api/price?chain=${c}`, { cache: "no-store" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();

      // Simpan cache untuk chain yang diminta
      priceCache[c] = {
        price:       data.price,
        priceChange: data.priceChange,
        ethPrice:    data.ethPrice ?? data.price,
        ts:          Date.now(),
      };

      // Kalau response mengandung harga ETH (dari chain ARB), cache sekalian untuk ETH
      // supaya saat pindah ke ETH tidak perlu fetch ulang
      if (c === "ARB" && data.ethPrice && data.ethPrice > 0 && !priceCache["ETH"]) {
        priceCache["ETH"] = {
          price:       data.ethPrice,
          priceChange: 0, // 24h change ETH tidak diambil saat fetch ARB, anggap 0
          ethPrice:    data.ethPrice,
          ts:          Date.now(),
        };
      }

      if (chainRef.current !== c) return;

      setPrice(data.price);
      setPriceChange(data.priceChange);
      setEthPrice(data.ethPrice ?? data.price);
      setIsLoading(false);
    } catch {
      if (chainRef.current === c) {
        // Gagal fetch — coba pakai cache lama kalau masih ada, jangan langsung 0
        const stale = priceCache[c];
        if (stale) {
          setPrice(stale.price);
          setPriceChange(stale.priceChange);
          setEthPrice(stale.ethPrice);
        } else {
          setPrice(0);
          setPriceChange(0);
          setEthPrice(0);
        }
        setIsLoading(false);
      }
    }
  };

  useEffect(() => {
    chainRef.current = chain;

    const cached = priceCache[chain];
    const now    = Date.now();

    if (cached && now - cached.ts < CACHE_TTL_MS) {
      // Cache masih fresh
      setPrice(cached.price);
      setPriceChange(cached.priceChange);
      setEthPrice(cached.ethPrice);
      setIsLoading(false);
    } else {
      // Tampilkan data lama dulu (stale) supaya tidak flash ke 0
      if (cached) {
        setPrice(cached.price);
        setPriceChange(cached.priceChange);
        setEthPrice(cached.ethPrice);
        setIsLoading(false);
      } else {
        setPrice(0);
        setPriceChange(0);
        setEthPrice(0);
        setIsLoading(true);
      }
      fetchPrice(chain);
    }

    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => fetchPrice(chain), 60_000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chain]);

  return { price, priceChange, isLoading, ethPrice };
}
